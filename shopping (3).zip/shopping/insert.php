<?php
$name=$_POST['n'];
$phno=$_POST['ph'];
$email=$_POST['e'];
$addr=$_POST['add'];
$pwd=$_POST['pw'];
$conn=mysqli_connect('localhost','root','Aditya123','shopping');
$query="insert into registration values('$name','$phno','$email','$addr','$pwd')";
$sql=mysqli_query($conn,$query);
if($sql)
echo "registered succecsfylly";
else
echo "sorry ";
?>