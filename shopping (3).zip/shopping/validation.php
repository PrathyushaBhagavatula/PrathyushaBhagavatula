
<?php
$email=$emailErr=$phoneErr=$phone="";

if(empty($_POST["phone"]))
{
	$phoneErr="phone number is required";
}
else
{
	$phone= test_input($_POST["phone"]);
	if(!preg_match("/^[6-9][0-9]{9}$/",$phone))
		$phoneErr= " invalid phone number";

     elseif(strlen($phone) < 10 )
        $phoneErr="mobile number cannot be too short....";
	 elseif(strlen($phone)>10)
		 $phoneErr="mobile number cannot be too long....";
}
	  
if (empty($_POST["email"])) 
	{
    $emailErr = "Email is required";
  } else
	  {
    $email = test_input($_POST["email"]);
    // check if e-mail address is well-formed
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) 
		  {
      $emailErr = "Invalid email format";
    }
  }
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
  ?>
<form method="POST" action="<?php echo htmlspecialchars($_SERVER[
	  "PHP_SELF"]);?>">
	  Email: <input type="text" placeholder="email" name="email"><span class="error" style="color:red">*<?php echo $emailErr;?></span> <br><br><br><br>
	  Phonemumber:<input type="text" placeholder="phonenumber" name="phone"><span class="error" style="color:red" >*<?php echo $phoneErr;?></span> <br><br><br><br>
	  <input type="submit" value="click" >
	  </form>