<?php

$email=$_POST['e'];

$pwd=$_POST['pw'];

$conn=mysqli_connect('localhost','root','Aditya123','shopping');
$query="select * from registration where email='$email' and pwd='$pwd'";
$sql=mysqli_query($conn,$query);
$count=mysqli_num_rows($sql);
if($count==1)
{
	session_start();
$_SESSION['email']=$email;
header("Location:shoppage.html");

}else
echo "Email or password is invalid";

?>