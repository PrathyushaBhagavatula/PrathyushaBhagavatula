<?php
session_start();
$email=$_SESSION['email'];
$conn=mysqli_connect('localhost','root','Aditya123','shopping');
$query="insert into product values('dress','759','$email')";
$sql=mysqli_query($conn,$query);
if($sql)
{
	echo "<body bgcolor=#82E0AA><center>";
	echo "<h3>ordered successfully</h3>";
	echo "<h4>click <a href='dress.html'>here</a> to order more</h4>";
}
else
{
	echo "<body bgcolor=#F1948A><center>";
	echo "<h3>ordered failed</h3>";
	echo "<h4>click <a href='dress.html'>here</a> to try again</h4>";

}
?>