<?php
$un=$_POST['n'];
$ph=$_POST['ph'];
$email=$_POST['e'];
$add=$_POST['add'];
$pwd=$_POST['pw'];

$conn=mysqli_connect('localhost','root','Aditya123','project');
$query="insert into register values('$un','$ph','$email','$addm','$pwd')";
$sql=mysqli_query($conn,$query);
if($sql)
echo "regsitered succecsfylly";
else
echo "sorry ";
?>