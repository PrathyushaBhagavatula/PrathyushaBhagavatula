<?php

$email=$_POST['e'];

$pwd=$_POST['pw'];

$conn=mysqli_connect('localhost','root','Aditya123','project');
$query="select * from register where email='$email' and pwd='$pwd'";
$sql=mysqli_query($conn,$query);
$count=mysqli_num_rows($sql);
if($count==1)
header("Location:welcome.html");
else
echo "Email or password is invalid";

?>